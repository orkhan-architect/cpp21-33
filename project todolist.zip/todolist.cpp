#include "todolist.h"
#include <iostream>

using namespace std;

todolist add_plan()
{
	FILE* files;

	todolist tmp_plan;

	tmp_plan.name = new char[20]{};
	tmp_plan.note = new char[100]{};
	tmp_plan.datetime = new unsigned short[3]{};

	fopen_s(&files, "info.txt", "a");

	cout << "Enter the name of the plan: ";
	gets_s(tmp_plan.name, 20);
	if (files != nullptr) {
		fputs("The name of the plan is ", files);
		fputs(tmp_plan.name, files);
		fputc('\n', files);
	}

	cout << "Enter the note of the plan: ";
	gets_s(tmp_plan.note, 100);
	if (files != nullptr) {
		fputs("The note of the plan is ", files);
		fputs(tmp_plan.note, files);
		fputc('\n', files);
	}

	char* date_buffer = new char[33]{};
	if (files != nullptr)
		fputs("The datetime of the plan is ", files);
	for (size_t i = 0; i < 3; i++) {
		if (i == 0)
			cout << "Enter the day of the plan : ";
		else if (i == 1)
			cout << "Enter the month of the plan : ";

		else
			cout << "Enter the year of the plan : ";

		cin >> tmp_plan.datetime[i];

		sprintf_s(date_buffer, 10, "%d", tmp_plan.datetime[i]);

		if (files != nullptr) {
			fputs(date_buffer, files);
			fputc('.', files);
		}
	}
	if (files != nullptr)
		fputc('\n', files);

	char* status_buffer = new char[33]{};
	cout
		<< "Enter the priority of the plan" << '\n'
		<< "0 - Lower" << '\n'
		<< "1 - Normal" << '\n'
		<< "2 - Higher" << '\n';
	cin >> tmp_plan.status;

	sprintf_s(status_buffer, 10, "%d", tmp_plan.status);

	if (files != nullptr) {
		fputs("The status (0-Lower, 1-Normal, 2-Higher) of the plan is ", files);
		fputs(status_buffer, files);
		fputc('\n', files);
	}

	while (tmp_plan.status < 0 || tmp_plan.status > 2) {
		cout << "Try again. Enter the priority (status 0-2) of the plan: ";
		cin >> tmp_plan.status;

		sprintf_s(status_buffer, 10, "%d", tmp_plan.status);

		if (files != nullptr) {
			fputs("The status (0-Lower, 1-Normal, 2-Higher) of the plan is ", files);
			fputs(status_buffer, files);
			fputc('\n', files);
		}
	}

	if (files != nullptr)
		fputs("-----------------------\n", files);

	if (files != nullptr)
		fclose(files);

	cout << endl;
	cin.clear();
	cin.ignore(INT_MAX, '\n');

	delete[] date_buffer;
	delete[] status_buffer;

	return tmp_plan;
}

void print_list(todolist plan)
{
	if (plan.status == 0)
		cout << "1. The status of the plan is " << "\t \t" << "LOWER" << '\n';
	else if (plan.status == 1)
		cout << "1. The status of the plan is " << "\t \t" << "NORMAL" << '\n';
	else
		cout << "1. The status of the plan is " << "\t \t" << "HIGHER" << '\n';

	cout
		<< "2. The name of the plan is " << "\t \t" << plan.name << '\n'
		<< "3. The date of the plan is " << "\t \t" << plan.datetime[0] << '.' << plan.datetime[1] << '.' << plan.datetime[2] << '\n'
		<< "4. The note of the plan is " << "\t \t" << plan.note << '\n';

	cout << endl;
}

void delete_plan(todolist* plan, int count)
{
	count--;
	unsigned short plan_choice = 0;

	cout << "Which plan do you want delete" << endl;
	for (size_t i = 0; i < count + 1; i++)
		cout << i + 1 << ". " << plan[i].name << endl;
	cin >> plan_choice;
	plan_choice--;

	cin.clear();
	cin.ignore(INT_MAX, '\n');

	todolist* tmp_list = new todolist[count];
	for (size_t i = 0; i < count + 1; i++) {
		if (i < plan_choice) {
			tmp_list[i] = plan[i];
		}
		else if (i == plan_choice) {
			continue;
		}
		else {
			tmp_list[i - 1] = plan[i];
		}
	}

	FILE* files;
	fopen_s(&files, "info.txt", "a");

	char* del_buffer = new char[33]{};
	sprintf_s(del_buffer, 10, "%d", plan_choice);
	if (files != nullptr) {
		fputs("The index of the deleted list is ", files);
		fputs(del_buffer, files);
		fputs("\n-----------------------\n", files);
	}

	for (size_t i = 0; i < count; i++)
		print_list(tmp_list[i]);

	if (files != nullptr)
		fclose(files);

	delete[] del_buffer;
}

void edit_plan(todolist* plan, int count)
{
	unsigned short plan_choice = 0;

	cout << "Which plan do you want edit" << endl;
	for (size_t i = 0; i < count; i++)
		cout << i + 1 << ". " << plan[i].name << endl;
	cin >> plan_choice;
	plan_choice--;

	cin.clear();
	cin.ignore(INT_MAX, '\n');

	FILE* files;
	fopen_s(&files, "info.txt", "a");

	char* edit_buffer = new char[33]{};
	sprintf_s(edit_buffer, 10, "%d", plan_choice);
	if (files != nullptr) {
		fputs("The index of the edited list is ", files);
		fputs(edit_buffer, files);
		fputs("\n-----------------------\n", files);
	}

	plan[plan_choice] = add_plan();

	if (files != nullptr)
		fclose(files);

	delete[] edit_buffer;
}

void plan_searcher(todolist* plan, int count)
{
	int search_operation = 0, status_num = 0;

	char* search_array = new char[20]{};
	unsigned short* search_date = new unsigned short[3]{};

	cout
		<< "Enter the operation number that you want proceed" << '\n'
		<< "1. Search by name" << '\n'
		<< "2. Search by note" << '\n'
		<< "3. Search by priority" << '\n'
		<< "4. Search by date" << '\n';

	cin >> search_operation;

	cin.clear();
	cin.ignore(INT_MAX, '\n');

	if (search_operation == 1 || search_operation == 2) {
		cout << "Enter the part that you will search for: ";
		gets_s(search_array, 20);
	}
	else if (search_operation == 3) {
		cout << "Enter the priority number between 0-2(Lower-Higer) that you will search for: ";
		cin >> status_num;
	}
	else {
		for (size_t i = 0; i < 3; i++) {
			if (i == 0) {
				cout << "Enter the day of the plan : ";
				cin >> search_date[i];
			}
			else if (i == 1) {
				cout << "Enter the month of the plan : ";
				cin >> search_date[i];
			}
			else {
				cout << "Enter the year of the plan : ";
				cin >> search_date[i];
			}
		}
	}

	FILE* files;
	fopen_s(&files, "info.txt", "a");

	switch (search_operation)
	{
	case 1:
		cout << endl;
		for (size_t i = 0; i < count; i++)
			if (_stricmp(search_array, plan[i].name) == 0)
				print_list(plan[i]);
		if (files != nullptr) {
			fputs("The list was searched for by name", files);
			fputs("\n-----------------------\n", files);
		}
		break;
	case 2:
		cout << endl;
		for (size_t i = 0; i < count; i++)
			if (_stricmp(search_array, plan[i].note) == 0)
				print_list(plan[i]);
		if (files != nullptr) {
			fputs("The list was searched for by note", files);
			fputs("\n-----------------------\n", files);
		}
		break;
	case 3:
		cout << endl;
		for (size_t i = 0; i < count; i++)
			if (status_num == plan[i].status)
				print_list(plan[i]);
		if (files != nullptr) {
			fputs("The list was searched for by priority", files);
			fputs("\n-----------------------\n", files);
		}
		break;
	case 4:
		cout << endl;
		for (size_t i = 0, j = 0; i < count; i++)
			if (search_date[j] == plan[i].datetime[j] &&
				search_date[j + 1] == plan[i].datetime[j + 1] &&
				search_date[j + 2] == plan[i].datetime[j + 2])
				print_list(plan[i]);
		if (files != nullptr) {
			fputs("The list was searched for by datetime", files);
			fputs("\n-----------------------\n", files);
		}
		break;
	default:
		cout << "You are out of the range. Try again." << endl;
		break;
	}

	if (files != nullptr)
		fclose(files);
}

int date_converter(unsigned short* dates)
{
	unsigned short ly_count = 0, year = dates[2];
	int days_count = 0;

	dates[2]--;

	for (size_t i = 1; i < dates[2]; i++)
		if ((i % 4 == 0) && (i % 100 != 0 || i % 400 == 0))
			ly_count++;

	days_count = ly_count * 366 + (dates[2] - ly_count) * 365;

	unsigned short* sy_month = new unsigned short[] { 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334 };
	unsigned short* ly_month = new unsigned short[] { 0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335 };

	for (size_t i = 0; i < 12; i++) {
		if ((dates[1] - 1) == i) {
			if ((year % 4 == 0) && (year % 100 != 0 || year % 400 == 0)) {
				days_count += ly_month[i];
			}
			else {
				days_count += sy_month[i];
			}
			break;
		}
	}

	days_count += dates[0];

	dates[2]++;

	return days_count;
}

void special_print(todolist* plan, int count)
{
	int show_operation = 0;
	cout
		<< "Enter the operation number that you want proceed" << '\n'
		<< "1. Show plans for current day" << '\n'
		<< "2. Show plans for a week" << '\n'
		<< "3. Show plans for a month" << '\n';
	cin >> show_operation;

	cin.clear();
	cin.ignore(INT_MAX, '\n');

	unsigned short* show_date = new unsigned short[3]{};
	for (size_t i = 0; i < 3; i++) {
		if (i == 0) {
			cout << "Enter the day of the plan : ";
			cin >> show_date[i];
		}
		else if (i == 1) {
			cout << "Enter the month of the plan : ";
			cin >> show_date[i];
		}
		else {
			cout << "Enter the year of the plan : ";
			cin >> show_date[i];
		}
	}

	int user_date = date_converter(show_date);

	int* plans_date = new int[count] {};
	for (size_t i = 0; i < count; i++)
		plans_date[i] = date_converter(plan[i].datetime);

	FILE* files;
	fopen_s(&files, "info.txt", "a");

	switch (show_operation)
	{
	case 1:
		cout << endl;
		for (size_t i = 0, j = 0; i < count; i++)
			if (show_date[j] == plan[i].datetime[j] &&
				show_date[j + 1] == plan[i].datetime[j + 1] &&
				show_date[j + 2] == plan[i].datetime[j + 2])
				print_list(plan[i]);
		if (files != nullptr) {
			fputs("The list was checked for current day", files);
			fputs("\n-----------------------\n", files);
		}
		break;
	case 2:
		cout << endl;
		for (size_t i = 0; i < count; i++)
			if (user_date <= plans_date[i] && plans_date[i] <= (user_date + 7))
				print_list(plan[i]);
		if (files != nullptr) {
			fputs("The list was checked for a week", files);
			fputs("\n-----------------------\n", files);
		}
		break;
	case 3:
		for (size_t i = 0; i < count; i++)
			if (user_date <= plans_date[i] && plans_date[i] <= (user_date + 30))
				print_list(plan[i]);
		if (files != nullptr) {
			fputs("The list was checked for a month", files);
			fputs("\n-----------------------\n", files);
		}
		break;
	default:
		cout << "You are out of the range. Try again." << endl;
		break;
	}

	if (files != nullptr)
		fclose(files);
}

void sorting_print(todolist* plan, int count)
{
	todolist* temp_array = new todolist[count];

	int date_generator = 0;

	int sort_operation = 0;
	cout
		<< "Enter the operation number that you want proceed" << '\n'
		<< "1. Sort plans by priority" << '\n'
		<< "2. Sort plans by datetime" << '\n';
	cin >> sort_operation;

	cin.clear();
	cin.ignore(INT_MAX, '\n');

	int* plans_date = new int[count] {};
	for (size_t i = 0; i < count; i++)
		plans_date[i] = date_converter(plan[i].datetime);

	FILE* files;
	fopen_s(&files, "info.txt", "a");

	switch (sort_operation)
	{
	case 1:
		for (int i = 0; i < count; i++) {
			for (int j = 0; j < (count - 1); j++) {
				if (plan[j].status > plan[j + 1].status) {
					temp_array[j] = plan[j];
					plan[j] = plan[j + 1];
					plan[j + 1] = temp_array[j];
				}
			}
		}
		cout << "Your list was sorted by priority, check your list. Click 2 ->" << endl;
		if (files != nullptr) {
			fputs("The list was sorted by priority", files);
			fputs("\n-----------------------\n", files);
		}
		break;
	case 2:
		for (int i = 0; i < count; i++) {
			for (int j = 0; j < (count - 1); j++) {
				if (plans_date[j] > plans_date[j + 1]) {
					temp_array[j] = plan[j];
					plan[j] = plan[j + 1];
					plan[j + 1] = temp_array[j];

					date_generator = plans_date[j];
					plans_date[j] = plans_date[j + 1];
					plans_date[j + 1] = date_generator;
				}
			}
		}
		cout << "Your list was sorted by datetime, check your list. Click 2 ->" << endl;
		if (files != nullptr) {
			fputs("The list was sorted by datetime", files);
			fputs("\n-----------------------\n", files);
		}
		break;
	default:
		cout << "You are out of the range. Try again." << endl;
		break;
	}

	if (files != nullptr)
		fclose(files);

	delete[] temp_array;
}