#pragma once

struct todolist {
	char* name;
	char* note;
	unsigned short* datetime;
	unsigned short status;
};

todolist add_plan();
void print_list(todolist plan);
void delete_plan(todolist* plan, int count);
void edit_plan(todolist* plan, int count);
void plan_searcher(todolist* plan, int count);
int date_converter(unsigned short* dates);
void special_print(todolist* plan, int count);
void sorting_print(todolist* plan, int count);