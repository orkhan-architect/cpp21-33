#include <iostream>
#include <cstdio>
#include <string.h>
#include "todolist.h"

using namespace std;

int main()
{
	int plans_count = 3, operation = 0;
	bool checking = true;

	todolist* my_array = new todolist[plans_count];

	while (checking) {
		cout
			<< "Enter the operation number that you want proceed" << '\n'
			<< "1. Add plans" << '\n'
			<< "2. Show plans" << '\n'
			<< "3. Delete plan" << '\n'
			<< "4. Edit plan" << '\n'
			<< "5. Search plan" << '\n'
			<< "6. Show chosen plans" << '\n'
			<< "7. Sort plans" << '\n'
			<< "8. EXIT" << '\n';

		cin >> operation;
		cin.clear();
		cin.ignore(INT_MAX, '\n');

		switch (operation)
		{
		case 1:
			for (size_t i = 0; i < plans_count; i++)
				my_array[i] = add_plan();
			break;
		case 2:
			cout << endl;
			for (size_t i = 0; i < plans_count; i++)
				print_list(my_array[i]);
			break;
		case 3:
			delete_plan(my_array, plans_count);
			break;
		case 4:
			cout << endl;
			edit_plan(my_array, plans_count);
			break;
		case 5:
			cout << endl;
			plan_searcher(my_array, plans_count);
			break;
		case 6:
			cout << endl;
			special_print(my_array, plans_count);
			break;
		case 7:
			cout << endl;
			sorting_print(my_array, plans_count);
			break;
		case 8:
			checking = false;
			break;
		default:
			cout << "You are out of the range. Try again." << endl;
			break;
		}
	}
	return 0;
}